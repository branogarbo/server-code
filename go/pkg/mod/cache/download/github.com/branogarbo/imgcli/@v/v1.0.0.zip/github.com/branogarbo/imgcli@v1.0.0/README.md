# imgcli
A simple Go program that prints images to the command line and more.
