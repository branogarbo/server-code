Tracking Youtube decipher change

### 2021/02/24:

#### action objects:

var Mx={nK:function(a,b){var c=a[0];a[0]=a[b%a.length];a[b%a.length]=c}, IT:function(a,b){a.splice(0,b)}, Th:function(a)
{a.reverse()}}
#### actions function:

Nx=function(a){a=a.split("");Mx.Th(a,74);Mx.IT(a,2);Mx.Th(a,8);Mx.nK(a,48);Mx.IT(a,1);Mx.nK(a,15);Mx.Th(a,15);return
a.join("")};
