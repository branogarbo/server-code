package main

import _ "github.com/kkdai/youtube/v2"

func main() {
}
