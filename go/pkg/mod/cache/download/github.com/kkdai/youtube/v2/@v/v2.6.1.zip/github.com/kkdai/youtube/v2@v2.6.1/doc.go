/*
Package youtube implement youtube download package in go.
*/
package youtube
