/*
Package goodbye provides a standard way to execute code when a process
exits normally or due to a signal.
*/
package goodbye
