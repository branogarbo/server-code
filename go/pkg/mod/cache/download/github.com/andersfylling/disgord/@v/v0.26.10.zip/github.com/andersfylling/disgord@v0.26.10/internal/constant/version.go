package constant

const Version = "v0"
