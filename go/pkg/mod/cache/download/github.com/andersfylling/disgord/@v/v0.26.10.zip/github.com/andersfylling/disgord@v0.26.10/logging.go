package disgord

import (
	"github.com/andersfylling/disgord/internal/logger"
)

// Logger super basic logging interface
type Logger = logger.Logger
