package constant

// DiscordVersion API version
const DiscordVersion = 8

// JSONEncoding the json encoding identifier
const JSONEncoding = "json"

const Encoding = JSONEncoding
