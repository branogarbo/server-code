package main

import "github.com/andersfylling/disgord"

func main() {
	_ = disgord.New(disgord.Config{})
}
