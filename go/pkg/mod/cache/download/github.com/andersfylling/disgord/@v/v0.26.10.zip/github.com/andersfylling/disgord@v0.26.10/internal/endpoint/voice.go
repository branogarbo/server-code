package endpoint

// VoiceRegions /voice/regions
func VoiceRegions() string {
	return voice + regions
}
