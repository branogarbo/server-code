package httd

import (
	"github.com/andersfylling/snowflake/v5"
)

type Snowflake = snowflake.Snowflake
