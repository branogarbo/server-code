package cmd

const (
	RequestGuildMembers = "REQUEST_GUILD_MEMBERS"
	UpdateVoiceState    = "UPDATE_VOICE_STATE"
	UpdateStatus        = "UPDATE_STATUS"
)
