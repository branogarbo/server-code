// crs Cache Replacement Strategy

package crs

import (
	"github.com/andersfylling/disgord/internal/util"
)

type Snowflake = util.Snowflake
