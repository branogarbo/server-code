package constant

const (
	GitHubURL = "https://github.com/andersfylling/disgord"
	Name      = "Disgord"
)
