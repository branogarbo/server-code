# Comparison
> NOTE! This is under development, so the comparison can be incorrect.

This file tries to show the difference between Disgord and other Discord libraries written in Go.

## Features

|           | Caching | REST API | Gateway API | User/self bot | Channels | Event Middleware |
|----------:|:-------:|:--------:|:-----------:|:-------------:|----------|------------------|
|   Disgord |    X    |     X    |      X      |               |     X    |         X        |
| DiscordGo |    X    |     X    |      X      |       X       |          |                  |

## REST

### Audit-logs

|           | Get |
|----------:|:---:|
|   Disgord |  X  |
| DiscordGo |     |

### Voice

|           | List Regions |
|----------:|:------------:|
|   Disgord |       X      |
| DiscordGo |       X      |