package cmd

const (
	VoiceIdentify       = "VOICE_IDENTIFY"
	VoiceSelectProtocol = "VOICE_SELECT_PROTOCOL"
	VoiceHeartbeat      = "VOICE_HEARTBEAT"
	VoiceSpeaking       = "VOICE_SPEAKING"
	VoiceResume         = "VOICE_RESUME"
)
