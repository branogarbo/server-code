# Limitations

Note that the Prisma Go client is a prototype at this time and not ready for production use. It's missing a lot of features compared to the javascript client. However, in most of the cases, you can always [fall back to using raw queries](11-raw.md).
