package composite

import (
	"testing"
)

func TestCompositeKeyConflict(t *testing.T) {
	t.Logf("success (compiling means succeeded)")
}
