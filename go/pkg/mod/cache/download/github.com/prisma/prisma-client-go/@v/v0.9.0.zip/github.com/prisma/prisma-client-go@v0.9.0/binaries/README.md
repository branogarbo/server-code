# Prisma binaries

## How to build Prisma CLI binaries

### Setup

Install [zeit/pkg](https://github.com/zeit/pkg):

```shell script
npm i -g pkg
```

### Build the binary and upload to S3

```shell script
sh publish.sh <version>
```
