package composite

import (
	"testing"
)

func TestRelationNameConflict(t *testing.T) {
	t.Logf("success (compiling means succeeded)")
}
