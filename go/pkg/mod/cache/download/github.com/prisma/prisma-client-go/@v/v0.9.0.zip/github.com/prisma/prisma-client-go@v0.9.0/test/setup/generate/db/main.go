package main

import "log"

func main() {
	// noop, we just need to wait for the init functions to be called
	log.Printf("unpacked binaries")
}
